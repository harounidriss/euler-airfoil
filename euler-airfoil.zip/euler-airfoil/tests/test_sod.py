import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from euler1d import (LEFT, RIGHT, T_END, cons_to_prim, exact_riemann, flux,  # noqa: E402
                     hll_flux, hllc_flux, l1_error, prim_to_cons, roe_flux,
                     sod_initial, solve)

FLUX_FUNCS = [roe_flux, hll_flux, hllc_flux]


def test_prim_cons_roundtrip():
    rho, u, p = 1.3, 0.7, 2.1
    assert np.allclose(cons_to_prim(prim_to_cons(rho, u, p)), (rho, u, p))


@pytest.mark.parametrize("numflux", FLUX_FUNCS)
def test_flux_consistency(numflux):
    """Consistance : Phi(U, U) = F(U)."""
    U = prim_to_cons(np.array([1.0, 0.5]), np.array([0.3, -0.4]), np.array([1.0, 0.8]))
    assert np.allclose(numflux(U, U), flux(U), atol=1e-12)


def test_exact_solution_star_state():
    """Zone centrale de Sod (Toro) : p* ≈ 0,30313, u* ≈ 0,92745."""
    rho, u, p = exact_riemann(LEFT, RIGHT, np.array([0.6]), T_END)
    assert p[0] == pytest.approx(0.30313, abs=1e-4)
    assert u[0] == pytest.approx(0.92745, abs=1e-4)


@pytest.mark.parametrize("scheme", ["Roe", "HLL", "HLLC"])
def test_conservation(scheme):
    """Masse et énergie conservées tant que les ondes n'atteignent pas les bords."""
    x, dx, U0 = sod_initial(200)
    U = solve(U0, dx, T_END, scheme, order=2)
    assert np.sum(U[0])*dx == pytest.approx(np.sum(U0[0])*dx, rel=1e-10)
    assert np.sum(U[2])*dx == pytest.approx(np.sum(U0[2])*dx, rel=1e-10)


@pytest.mark.parametrize("scheme", ["Roe", "HLLC"])
def test_positivity_and_accuracy(scheme):
    x, dx, U0 = sod_initial(200)
    rho, u, p = cons_to_prim(solve(U0, dx, T_END, scheme, order=2))
    assert rho.min() > 0 and p.min() > 0
    assert l1_error(200, scheme, 2) < 6e-3


@pytest.mark.parametrize("scheme", ["Roe", "HLLC"])
def test_muscl_beats_first_order(scheme):
    assert l1_error(200, scheme, 2) < l1_error(200, scheme, 1)


@pytest.mark.parametrize("scheme", ["Roe", "HLLC"])
def test_convergence_with_mesh(scheme):
    assert l1_error(400, scheme, 2) < l1_error(100, scheme, 2)
