"""Solveur 1D des équations d'Euler en volumes finis (HLL, HLLC, Roe + MUSCL + SSP-RK2).

Étape 1 du projet « écoulement d'air autour d'un aéronef ».
"""
import numpy as np

GAMMA = 1.4

def prim_to_cons(rho, u, p):
    return np.array([rho, rho*u, p/(GAMMA-1) + 0.5*rho*u**2])

def cons_to_prim(U):
    rho = U[0]
    u = U[1]/rho
    p = (GAMMA-1)*(U[2] - 0.5*rho*u**2)
    return rho, u, p

def sound_speed(rho, p):
    return np.sqrt(GAMMA*p/rho)

def flux(U):
    rho, u, p = cons_to_prim(U)
    return np.array([rho*u, rho*u**2 + p, u*(U[2] + p)])

def hll_flux(UL, UR):
    rhoL, uL, pL = cons_to_prim(UL); rhoR, uR, pR = cons_to_prim(UR)
    cL, cR = sound_speed(rhoL, pL), sound_speed(rhoR, pR)
    SL = np.minimum(uL - cL, uR - cR)
    SR = np.maximum(uL + cL, uR + cR)
    FL, FR = flux(UL), flux(UR)
    Fhll = (SR*FL - SL*FR + SL*SR*(UR - UL))/(SR - SL)
    return np.where(SL >= 0, FL, np.where(SR <= 0, FR, Fhll))


def hllc_flux(UL, UR):
    rhoL, uL, pL = cons_to_prim(UL); rhoR, uR, pR = cons_to_prim(UR)
    cL, cR = sound_speed(rhoL, pL), sound_speed(rhoR, pR)
    SL = np.minimum(uL - cL, uR - cR)
    SR = np.maximum(uL + cL, uR + cR)
    SM = (pR - pL + rhoL*uL*(SL - uL) - rhoR*uR*(SR - uR)) / (rhoL*(SL - uL) - rhoR*(SR - uR))
    FL, FR = flux(UL), flux(UR)

    def star_state(U, rho, u, p, S):
        fac = rho*(S - u)/(S - SM)
        return fac*np.array([np.ones_like(u),
                             SM*np.ones_like(u),
                             U[2]/rho + (SM - u)*(SM + p/(rho*(S - u)))])

    UsL = star_state(UL, rhoL, uL, pL, SL)
    UsR = star_state(UR, rhoR, uR, pR, SR)
    return np.where(SL >= 0, FL,
           np.where(SM >= 0, FL + SL*(UsL - UL),
           np.where(SR > 0,  FR + SR*(UsR - UR), FR)))


def roe_flux(UL, UR):
    rhoL, uL, pL = cons_to_prim(UL); rhoR, uR, pR = cons_to_prim(UR)
    HL, HR = (UL[2] + pL)/rhoL, (UR[2] + pR)/rhoR
    sL, sR = np.sqrt(rhoL), np.sqrt(rhoR)
    u = (sL*uL + sR*uR)/(sL + sR)
    H = (sL*HL + sR*HR)/(sL + sR)
    c = np.sqrt((GAMMA-1)*(H - 0.5*u**2))
    rho = sL*sR

    drho, du, dp = rhoR - rhoL, uR - uL, pR - pL
    a1 = (dp - rho*c*du)/(2*c**2)
    a2 = drho - dp/c**2
    a3 = (dp + rho*c*du)/(2*c**2)

    lam = np.array([u - c, u, u + c])
    delta = 0.1*c                       # correction d'entropie (Harten)
    lam_abs = np.where(np.abs(lam) < delta, (lam**2 + delta**2)/(2*delta), np.abs(lam))

    one = np.ones_like(u)
    K1 = np.array([one, u - c, H - u*c])
    K2 = np.array([one, u, 0.5*u**2])
    K3 = np.array([one, u + c, H + u*c])
    diss = lam_abs[0]*a1*K1 + lam_abs[1]*a2*K2 + lam_abs[2]*a3*K3
    return 0.5*(flux(UL) + flux(UR)) - 0.5*diss


FLUXES = {"HLL": hll_flux, "HLLC": hllc_flux, "Roe": roe_flux}

def minmod(a, b):
    return 0.5*(np.sign(a) + np.sign(b))*np.minimum(np.abs(a), np.abs(b))

def interface_states(U, order):
    N = U.shape[1]
    Ug = np.pad(U, ((0, 0), (2, 2)), mode="edge")        # mailles fantômes
    if order == 1:
        return Ug[:, 1:N+2], Ug[:, 2:N+3]
    W = np.array(cons_to_prim(Ug))
    s = minmod(W[:, 1:-1] - W[:, :-2], W[:, 2:] - W[:, 1:-1])   # pentes mailles 1..N+2
    WL = W[:, 1:N+2] + 0.5*s[:, 0:N+1]
    WR = W[:, 2:N+3] - 0.5*s[:, 1:N+2]
    return prim_to_cons(*WL), prim_to_cons(*WR)

def rhs(U, dx, numflux, order):
    UL, UR = interface_states(U, order)
    F = numflux(UL, UR)
    return -(F[:, 1:] - F[:, :-1])/dx

def solve(U0, dx, t_end, scheme="HLLC", order=2, cfl=0.4):
    numflux = FLUXES[scheme]
    U, t = U0.copy(), 0.0
    while t < t_end - 1e-14:
        rho, u, p = cons_to_prim(U)
        smax = np.max(np.abs(u) + sound_speed(rho, p))
        dt = min(cfl*dx/smax, t_end - t)
        if order == 1:
            U = U + dt*rhs(U, dx, numflux, 1)
        else:
            U1 = U + dt*rhs(U, dx, numflux, 2)
            U = 0.5*(U + U1 + dt*rhs(U1, dx, numflux, 2))
        t += dt
    return U

def exact_riemann(left, right, x, t, x0=0.5):
    g = GAMMA
    rhoL, uL, pL = left; rhoR, uR, pR = right
    cL, cR = np.sqrt(g*pL/rhoL), np.sqrt(g*pR/rhoR)

    def f(p, rho, pk, ck):
        if p > pk:
            A = 2/((g+1)*rho); B = (g-1)/(g+1)*pk
            return (p - pk)*np.sqrt(A/(p + B))
        return 2*ck/(g-1)*((p/pk)**((g-1)/(2*g)) - 1)

    def fp(p, rho, pk, ck):
        if p > pk:
            A = 2/((g+1)*rho); B = (g-1)/(g+1)*pk
            return np.sqrt(A/(B + p))*(1 - (p - pk)/(2*(B + p)))
        return (1/(rho*ck))*(p/pk)**(-(g+1)/(2*g))

    p = 0.5*(pL + pR)
    for _ in range(100):
        F = f(p, rhoL, pL, cL) + f(p, rhoR, pR, cR) + (uR - uL)
        dF = fp(p, rhoL, pL, cL) + fp(p, rhoR, pR, cR)
        pn = max(p - F/dF, 1e-10)
        if abs(pn - p) < 1e-13*0.5*(pn + p):
            p = pn; break
        p = pn
    ps = p
    us = 0.5*(uL + uR) + 0.5*(f(ps, rhoR, pR, cR) - f(ps, rhoL, pL, cL))

    def sample(xi):
        if xi <= us:                                     # à gauche du contact
            if ps > pL:                                   # choc gauche
                SL = uL - cL*np.sqrt((g+1)/(2*g)*ps/pL + (g-1)/(2*g))
                if xi < SL: return rhoL, uL, pL
                return rhoL*((ps/pL + (g-1)/(g+1))/((g-1)/(g+1)*ps/pL + 1)), us, ps
            cLs = cL*(ps/pL)**((g-1)/(2*g))               # détente gauche
            head, tail = uL - cL, us - cLs
            if xi < head: return rhoL, uL, pL
            if xi > tail: return rhoL*(ps/pL)**(1/g), us, ps
            u = 2/(g+1)*(cL + (g-1)/2*uL + xi)
            c = 2/(g+1)*(cL + (g-1)/2*(uL - xi))
            return rhoL*(c/cL)**(2/(g-1)), u, pL*(c/cL)**(2*g/(g-1))
        else:                                            # à droite du contact
            if ps > pR:                                   # choc droit
                SR = uR + cR*np.sqrt((g+1)/(2*g)*ps/pR + (g-1)/(2*g))
                if xi > SR: return rhoR, uR, pR
                return rhoR*((ps/pR + (g-1)/(g+1))/((g-1)/(g+1)*ps/pR + 1)), us, ps
            cRs = cR*(ps/pR)**((g-1)/(2*g))               # détente droite
            head, tail = uR + cR, us + cRs
            if xi > head: return rhoR, uR, pR
            if xi < tail: return rhoR*(ps/pR)**(1/g), us, ps
            u = 2/(g+1)*(-cR + (g-1)/2*uR + xi)
            c = 2/(g+1)*(cR - (g-1)/2*(uR - xi))
            return rhoR*(c/cR)**(2/(g-1)), u, pR*(c/cR)**(2*g/(g-1))

    out = np.array([sample((xx - x0)/t) for xx in x])
    return out[:, 0], out[:, 1], out[:, 2]

# ---------------- Cas test de Sod ----------------
LEFT, RIGHT = (1.0, 0.0, 1.0), (0.125, 0.0, 0.1)
T_END = 0.2


def sod_initial(N):
    """Maillage uniforme de [0,1] et état initial du tube à choc de Sod."""
    dx = 1.0/N
    x = (np.arange(N) + 0.5)*dx
    U0 = np.where(x < 0.5, prim_to_cons(*LEFT)[:, None], prim_to_cons(*RIGHT)[:, None])
    return x, dx, U0


def l1_error(N, scheme, order, t_end=T_END):
    """Erreur L1 sur la densité par rapport à la solution exacte."""
    x, dx, U0 = sod_initial(N)
    U = solve(U0, dx, t_end, scheme, order)
    rho_ex = exact_riemann(LEFT, RIGHT, x, t_end)[0]
    return dx*np.sum(np.abs(U[0] - rho_ex))
