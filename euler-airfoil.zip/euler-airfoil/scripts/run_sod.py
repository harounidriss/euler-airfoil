"""Reproduit les figures et le tableau de convergence du rapport (tube à choc de Sod)."""
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from euler1d import (LEFT, RIGHT, T_END, cons_to_prim, exact_riemann,  # noqa: E402
                     l1_error, sod_initial, solve)

OUT = Path(__file__).resolve().parents[1] / "figures"
OUT.mkdir(exist_ok=True)

# --- Comparaison des flux (N = 200) ---
N = 200
x, dx, U0 = sod_initial(N)
xe = np.linspace(0, 1, 1000)
ex = exact_riemann(LEFT, RIGHT, xe, T_END)

fig, axes = plt.subplots(1, 3, figsize=(15, 4))
names = [r"densité $\rho$", r"vitesse $u$", r"pression $p$"]
for scheme, mk in zip(["Roe", "HLL", "HLLC"], ["o", "s", "^"]):
    W = cons_to_prim(solve(U0, dx, T_END, scheme, order=2))
    for k in range(3):
        axes[k].plot(x, W[k], mk, ms=3, mfc="none", label=scheme)
for k in range(3):
    axes[k].plot(xe, ex[k], "k-", lw=1, label="exacte")
    axes[k].set_title(names[k]); axes[k].set_xlabel("x"); axes[k].grid(alpha=.3)
axes[0].legend()
plt.suptitle(f"Sod, N={N}, MUSCL-minmod + SSP-RK2")
plt.tight_layout(); plt.savefig(OUT/"sod_comparaison.png", dpi=150); plt.close()

# --- Convergence ---
Ns = [50, 100, 200, 400, 800]
results = {(s, o): [l1_error(n, s, o) for n in Ns] for s in ["Roe", "HLLC"] for o in [1, 2]}

print(f"{'schéma':<8}{'ordre':<7}" + "".join(f"N={n:<9}" for n in Ns) + "ordres observés")
for (s, o), errs in results.items():
    rates = [np.log2(errs[i]/errs[i+1]) for i in range(len(errs)-1)]
    print(f"{s:<8}{o:<7}" + "".join(f"{e:<11.2e}" for e in errs) + " ".join(f"{r:.2f}" for r in rates))

plt.figure(figsize=(6, 4.5))
for (s, o), errs in results.items():
    plt.loglog(Ns, errs, "o-", label=f"{s}, ordre {o}")
plt.loglog(Ns, [results[("HLLC", 1)][0]*(Ns[0]/n) for n in Ns], "k--", lw=.8, label="pente 1")
plt.xlabel("N"); plt.ylabel(r"erreur $L^1$ sur $\rho$"); plt.grid(alpha=.3, which="both"); plt.legend()
plt.tight_layout(); plt.savefig(OUT/"sod_convergence.png", dpi=150); plt.close()
print("Figures écrites dans", OUT)
